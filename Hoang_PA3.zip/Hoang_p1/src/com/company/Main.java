package com.company;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

import static java.lang.System.exit;

public class Main {

    static Scanner scnr = new Scanner(System.in);
    static Random SecureRandom = new Random();
    static double THRESHOLD = 0.001;

    public static void main(String[] args) throws IOException {
        int difficulty = getDifficulty();
        int gameType = getGametype();
        int correct = 0;
        int incorrect = 0;
        for (int i = 0; i < 10; i++) {
            double question = getNewQuestion(difficulty,gameType);
            double answer;
            answer = scnr.nextDouble();

            /*while (answer != question) {

             */
            if (Math.abs(answer - question) > THRESHOLD) {
                getBadResponse();
                incorrect++;
/* Pt1      System.out.print("What is " + num1 + " times " + num2 + "? ");
            answer = scnr.nextInt();
*/
            }

            if (Math.abs(answer - question) < THRESHOLD) {
                getGoodResponse();
                correct++;
            // getNewQuestion();
            }
        }
        System.out.println("Correct Answers: " + correct);
        System.out.println("Incorrect Answers: " + incorrect);
        double percentCorrect = (double) (correct * 100) / (double) (correct + incorrect);
        System.out.println("Percent Correct = " + percentCorrect + "%");
        double checker = percentCorrect - 75.00;
        if (checker > THRESHOLD)
            System.out.println("Congratulations, you are ready to go to the next level!");
        else
            System.out.println("Please ask your teacher for extra help.");
        System.out.print("Continue? (Y/N) ");
        char redo = (char) System.in.read();
        if(redo == 'Y' || redo == 'y')
            main(args);
        else exit(0);
    }

    public static int getDifficulty(){
        System.out.print("Enter a difficulty level. (1-4) ");
        return scnr.nextInt();
    }

    public static int getGametype(){
        System.out.print("Select Mode: 1 for addition 2 for multiplication 3 for subtraction or 4 for division 5 for combination ");
        return scnr.nextInt();
    }
    public static void getBadResponse(){
        int responses = SecureRandom.nextInt(4) + 1;
        switch (responses) {
            case 1:
                System.out.println("No. Please try again.");
                break;
            case 2:
                System.out.println("Wrong. Try once more.");
                break;
            case 3:
                System.out.println("Don’t give up!");
                break;
            default:
                System.out.println("No. Keep trying.");
                break;
        }
    }
    public static void getGoodResponse(){
        int responses = SecureRandom.nextInt(4) + 1;
        switch (responses) {
            case 1:
                System.out.println("Very good!");
                break;
            case 2:
                System.out.println("Excellent!");
                break;
            case 3:
                System.out.println("Nice work!");
                break;
            default:
                System.out.println("Keep up the good work!");
                break;
        }
    }
    // write your code here
    public static double getNewQuestion(int difficulty, int gameType) {
        int num1; int num2; double num3; double num4;
        if (difficulty == 1) {
            num1 = SecureRandom.nextInt(10);
            num2 = SecureRandom.nextInt(10);
        } else if (difficulty == 2) {
            num1 = SecureRandom.nextInt(100);
            num2 = SecureRandom.nextInt(100);
        } else if (difficulty == 3) {
            num1 = SecureRandom.nextInt(1000);
            num2 = SecureRandom.nextInt(1000);
        } else {
            num1 = SecureRandom.nextInt(10000);
            num2 = SecureRandom.nextInt(10000);
        }
        /*
        int question = num1 * num2;
         */
        int question; double divisionQuestion;
        if(gameType == 5)
            gameType = SecureRandom.nextInt(4)+1;
        if(gameType == 2) {
            System.out.print("What is " + num1 + " times " + num2 + "? ");
            question = num1 * num2;
            return question;
        }
        else if(gameType == 1) {
            System.out.print("What is " + num1 + " plus " + num2 + "? ");
            question = num1 + num2;
            return question;
        }
        else if(gameType == 3) {
            System.out.print("What is " + num1 + " minus " + num2 + "? ");
            question = num1 - num2;
            return question;
        }
        else {
            while (num2 == 0) {
                if(difficulty == 1)
                    num2 = SecureRandom.nextInt(10);
                else if(difficulty == 2)
                    num2 = SecureRandom.nextInt(100);
                else if(difficulty == 3)
                    num2 = SecureRandom.nextInt(1000);
                else num2 = SecureRandom.nextInt(10000);
            }
            num3 = num1;
            num4 = num2;
            System.out.print("What is " + num3 + " divided " + num4 + "? (3 places) ");
            divisionQuestion = num3 / num4;
            return divisionQuestion;
        }
    }
}

