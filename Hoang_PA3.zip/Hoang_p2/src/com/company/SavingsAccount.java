package com.company;
public class SavingsAccount {
    private double savingsBalance;

    public double calcMonthlyInterest(double savingsBalance, double annualInterestRate) {
        return savingsBalance * annualInterestRate / 12;
    }

    public void setBalance(double savingsBalance) {
        this.savingsBalance = savingsBalance;
    }

    public double getBalance() {
        return savingsBalance;
    }

}