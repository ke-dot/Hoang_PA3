package com.company;
public class Application {
    private static double annualInterestRate = 0.04;
    public static void main(String[] args) {
        SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();
        saver1.setBalance(2000.00);
        saver2.setBalance(3000.00);

        for (int i =0;i<12;i++){
        double saver1Interest = saver1.calcMonthlyInterest(saver1.getBalance(),annualInterestRate);
        saver1.setBalance(saver1.getBalance() + saver1Interest);
        System.out.printf("Saver 1 Month %d @ 4 percent: $%.2f \n",i+1,saver1.getBalance());

        double saver2Interest = saver2.calcMonthlyInterest(saver2.getBalance(),annualInterestRate);
        saver2.setBalance(saver2.getBalance() + saver2Interest);
        System.out.printf("Saver 2 Month %d @ 4 percent: $%.2f \n",i+1,saver2.getBalance());
        }

        modifyInterestRate();

        double saver1Interest = saver1.calcMonthlyInterest(saver1.getBalance(),annualInterestRate);
        saver1.setBalance(saver1.getBalance() + saver1Interest);
        System.out.println("Saver 1 Month 13 @ 5 percent: " + saver1.getBalance());

        double saver2Interest = saver2.calcMonthlyInterest(saver2.getBalance(),annualInterestRate);
        saver2.setBalance(saver2.getBalance() + saver2Interest);
        System.out.println("Saver 2 Month 13 @ 5 percent: " + saver2.getBalance());
        // write your code here
    }

    public static void modifyInterestRate(){
        annualInterestRate =  0.05;
    }
}

